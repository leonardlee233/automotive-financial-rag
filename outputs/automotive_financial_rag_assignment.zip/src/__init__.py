"""Financial-report RAG package."""

